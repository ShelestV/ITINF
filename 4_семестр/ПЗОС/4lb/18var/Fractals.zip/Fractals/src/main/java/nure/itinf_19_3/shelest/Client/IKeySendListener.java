package nure.itinf_19_3.shelest.Client;

public interface IKeySendListener {
    void send();
}

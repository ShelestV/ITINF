package nure.itinf_19_3.shelest.Resources;

public class Iteration {
    private int iteration;

    public Iteration() {
        iteration = 0;
    }

    public void setIteration(int iteration) {
        this.iteration = iteration;
    }

    public int getIteration() {
        return iteration;
    }
}
